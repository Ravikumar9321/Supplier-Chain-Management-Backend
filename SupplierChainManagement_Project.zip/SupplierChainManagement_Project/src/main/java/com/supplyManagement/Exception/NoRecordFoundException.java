package com.supplyManagement.Exception;

public class NoRecordFoundException  extends RuntimeException{

	public NoRecordFoundException(String msg) {
		super(msg);
	}
	

}
