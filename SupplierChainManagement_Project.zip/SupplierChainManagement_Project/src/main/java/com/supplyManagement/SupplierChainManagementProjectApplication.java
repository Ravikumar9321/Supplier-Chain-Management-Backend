package com.supplyManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupplierChainManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupplierChainManagementProjectApplication.class, args);
	}

}
