package com.supplyManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupplierChainManagementProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
